import  React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

import HomeScreen from './screens/HomeScreen';
import JokesScreen from './screens/JokesScreen';
import YogaScreen from './screens/YogaScreen';
import VideoScreen from './screens/VideoScreen';

const Stack = createStackNavigator();

export default class App extends React.Component{
  render(){
    return(
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home" screenOptions={{
        headerShown: false
      }}>
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="Jokes Screen" component={JokesScreen} />
        <Stack.Screen name="Video Screen" component={VideoScreen} />
         <Stack.Screen name="Yoga Screen" component={YogaScreen} />
      </Stack.Navigator>
    </NavigationContainer>
    )
  }
}

