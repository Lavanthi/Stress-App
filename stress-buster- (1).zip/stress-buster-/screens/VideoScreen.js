import  React from 'react';
import { View, StyleSheet, Button , SafeAreaView, Platform, StatusBar, Text} from 'react-native';
import { Video, AVPlaybackStatus } from 'expo-av';
//import Video from 'react-native-video';



export default function VideoScreen() {
  const video = React.useRef(null);
  const [status, setStatus] = React.useState({});
  return (
    <View style={styles.container}>
      <SafeAreaView style={styles.droidSafeArea}/>
      <View style={styles.titleBar}>
          <Text style={styles.titleText}>Stress Buster  </Text>
      </View>
      <View style={styles.pageTitleBar}>
          <Text style={styles.pageTitleText}>Video Screen </Text>
      </View>
      <Video
        ref={video}
        style={styles.video}
        source={require("../assets/videos/Palms.mp4")}
        useNativeControls
        resizeMode="contain"
        isLooping
        onPlaybackStatusUpdate={status => setStatus(() => status)}
      />
      <View style={styles.buttons}>
        <Button color = '#013220'
          title={status.isPlaying ? 'Pause' : 'Play'}
          onPress={() =>
            status.isPlaying ? video.current.pauseAsync() : video.current.playAsync()
          }
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
      backgroundColor:"teal",
      flex: 1,
      width:'100%'
  },

  droidSafeArea: {
        marginTop: Platform.OS === "android" ? StatusBar.currentHeight : 0
  },
  video: {
    marginTop: 50,
    alignSelf: 'center',
    width: 320,
    height: 200,
  },
  buttons: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  titleBar: {
        flex: 0.15,
        justifyContent: "center",
        alignItems: "center",
        marginTop:30
  },
  titleText: {
        fontSize: 40,
        fontWeight: "bold",
        color: "white"
  },
  pageTitleBar: {
        flex: 0.1,
        justifyContent: "center",
        alignItems: "center",
        marginTop:40
  },
  pageTitleText: {
        fontSize: 25,
        fontWeight: "bold",
        color: "white"
  },
  
});

