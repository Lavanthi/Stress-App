import  React from 'react';
import { View, StyleSheet, Button , SafeAreaView, Platform, StatusBar, Text, ScrollView} from 'react-native';
import { Video, AVPlaybackStatus } from 'expo-av';
//import Video from 'react-native-video';



export default function JokesScreen() {
  const video = React.useRef(null);
  const [status, setStatus] = React.useState({});
  return (
    <View style={styles.container}>
      <SafeAreaView style={styles.droidSafeArea}/>
      <View style={styles.titleBar}>
          <Text style={styles.titleText}>Stress Buster  </Text>
      </View>
      <View style={styles.pageTitleBar}>
          <Text style={styles.pageTitleText}>Jokes Screen </Text>
      </View>
      <ScrollView>
          <View style = {styles.jokesContainer}>
              <Text style={styles.jokeText}> 1) Never trust an atom because they make up everything. </Text>
          </View>
          <View style = {styles.jokesContainer}>
              <Text style={styles.jokeText}> 2) If you ever feel you've embarrassed yourself, just remember Archimedes ;p </Text>
          </View>

          <View style = {styles.jokesContainer}>
              <Text style={styles.jokeText}> 3) I was walking past a farm, and a sign read: “Duck, eggs!” I thought, “That’s an unnecessary comma.” Then it hit me.
</Text>
          </View>

          <View style = {styles.jokesContainer}>
              <Text style={styles.jokeText}> 4) My elderly relatives liked to tease me at weddings, saying, “You’ll be next!” They soon stopped though, once I started doing the same to them at funerals. </Text>
          </View>

          <View style = {styles.jokesContainer}>
              <Text style={styles.jokeText}> 5) I just got my doctor's test results and I'm really upset. Turns out, I'm not gonna be a doctor.</Text>
          </View>

          <View style = {styles.jokesContainer}>
              <Text style={styles.jokeText}> 6) The other day, my wife asked me to pass her lipstick but I accidentally passed her a glue stick. She still isn't talking to me.</Text>
          </View>
          
          <View style = {styles.jokesContainer}>
              <Text style={styles.jokeText}> 7) Never break someone's heart, they only have one. Break their bones instead, they have 206 of them.</Text>
          </View>

          <View style = {styles.jokesContainer}>
              <Text style={styles.jokeText}> 8) "I work with animals," the guy says to his date.  "That's so sweet," she replies. "I love a man who cares about animals. Where do you work?" "I'm a butcher," he says.</Text>
          </View>
          
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
      backgroundColor:"teal",
      flex: 1,
      width:'100%'
  },

  droidSafeArea: {
        marginTop: Platform.OS === "android" ? StatusBar.currentHeight : 0
  },
  video: {
    marginTop: 50,
    alignSelf: 'center',
    width: 320,
    height: 200,
  },
  buttons: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  titleBar: {
        flex: 0.15,
        justifyContent: "center",
        alignItems: "center",
        marginTop:30
  },
  titleText: {
        fontSize: 40,
        fontWeight: "bold",
        color: "white"
  },
  pageTitleBar: {
        flex: 0.1,
        justifyContent: "center",
        alignItems: "center",
        marginTop:40
  },
  pageTitleText: {
        fontSize: 25,
        fontWeight: "bold",
        color: "white"
  },
  jokesContainer:{
      
      marginLeft: 20,
      marginRight: 20,
      marginTop: 20,
      marginBottom:20,
      borderRadius: 20,
      backgroundColor: '#c4f2e9',
      alignItems:'center',
      justifyContent: 'center'
  },
  jokeText:{
    fontSize: 20,
    color: "black",
    width: "90%"
  }
});

