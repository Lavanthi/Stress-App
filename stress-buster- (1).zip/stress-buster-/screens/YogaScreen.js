import  React from 'react';
import { View, StyleSheet, Button , SafeAreaView, Platform, StatusBar, Text, ScrollView} from 'react-native';
import { Video, AVPlaybackStatus } from 'expo-av';
//import Video from 'react-native-video';



export default function YogaScreen() {
  const video = React.useRef(null);
  const [status, setStatus] = React.useState({});
  return (
    <View style={styles.container}>
      <SafeAreaView style={styles.droidSafeArea}/>
      <View style={styles.titleBar}>
          <Text style={styles.titleText}>Stress Buster  </Text>
          
      </View>
      <View style={styles.pageTitleBar}>
          <Text style={styles.pageTitleText}>Yoga Screen </Text>
      </View>
      <ScrollView>
          <View style = {styles.instructionsContainer}>
              <Text style={styles.instructionText}> * If you have a history of a chronic disease or are recovering from an injury, consult your physician before commencing. Let your yoga teacher know of any injuries or pains. </Text>
              <Text style={styles.instructionText}> * Do what you easily can. There is no competition. You are expected to move at your own pace. Listen to your body and do not push yourself. </Text>
             <Text style={styles.instructionText}> *Be patient and give your body the time to respond. Focus on the breath, right from the beginning.</Text> 
             <Text style={styles.instructionText}> * Don't get discouraged by the initial lack of flexibility or strength, it improves over time.</Text>
          </View>
 
 <View style = {styles.yogaContainer}>
              <Text style={styles.yogaHeader}>Vrikshasana (Tree Pose) </Text>
              <Text style={styles.yogaText}>  This pose gives you a sense of grounding. It improves your balance and strengthens your legs and back. It replicates the steady stance of a tree. Place your right foot high up on your left thigh. The sole of the foot should be flat and placed firmly. Keep your left leg straight and find your balance. While inhaling, raise your arms over your head and bring your palms together. Ensure that your spine is straight and take a few deep breaths. Slowly exhale, bring your hands down and release your right leg. Back in the standing position repeat the same with the other leg.</Text>
          </View>

          <View style = {styles.yogaContainer}>
              <Text style={styles.yogaHeader}> Tadasana (Mountain Pose)</Text>
              <Text style={styles.yogaText}>  This pose teaches one to stand with majestic steadiness like a mountain. The word ‘Tada' means a mountain, that's where the name comes from. It involves the major groups of muscles and improves focus and concentration. It is the starting position for all the other asanas.Stand with your heels slightly apart and hang your arms besides the torso. Gently lift and spread your toes and the balls of your feet, then lay them softly down on the floor. Balance your body weight on your feet. Lift your ankles and firm your thigh muscles while rotating them inwards. As you inhale, elongate your torso and when you exhale release your shoulder blades away from your head. Broaden your collarbone and elongate your neck. Your ears, shoulders, hips and ankles should all be in one line. You can check your alignment by standing against the wall initially. You can even raise your hands and stretch them. Breathe easy.</Text>
          </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
      backgroundColor:"teal",
      flex: 1,
      width:'100%'
  },

  droidSafeArea: {
        marginTop: Platform.OS === "android" ? StatusBar.currentHeight : 0
  },
  
  titleBar: {
        flex: 0.15,
        justifyContent: "center",
        alignItems: "center",
        marginTop:30
  },
  titleText: {
        fontSize: 40,
        fontWeight: "bold",
        color: "white"
  },
  pageTitleBar: {
        flex: 0.1,
        justifyContent: "center",
        alignItems: "center",
        marginTop:40
  },
  pageTitleText: {
        fontSize: 25,
        fontWeight: "bold",
        color: "white"
  },
  yogaContainer:{
      
      marginLeft: 20,
      marginRight: 20,
      marginTop: 20,
      marginBottom:20,
      borderRadius: 20,
      backgroundColor: '#c4f2e9',
      alignItems:'center',
      justifyContent: 'center'
  },
  instructionsContainer:{
      marginLeft: 20,
      marginRight: 20,
      marginTop: 20,
      marginBottom:20,
      borderRadius: 20,
      backgroundColor: '#013235',
      alignItems:'center',
      justifyContent: 'center',
      paddingBottom:15
  },
  instructionText:{
    marginTop: 10,
    fontSize: 15,
    color: "white",
    width: "90%"
  },
  yogaText:{
    fontSize: 20,
    color: "black",
    width: "90%",
    marginBottom:5
  },
  yogaHeader:{
    alignItems: 'center',
    fontSize: 23,
    marginBottom:5
  }
});

